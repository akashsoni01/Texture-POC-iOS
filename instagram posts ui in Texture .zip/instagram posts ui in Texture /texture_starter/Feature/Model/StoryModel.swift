//
//  StoryModel.swift
//  texture_starter
//
//  Created by arya.surya on 12/06/21.
//

import Foundation

public struct StoryModel {
    public let userAvatar: String
    public let userName: String
}
